<?php echo e($slot); ?>

<?php /**PATH E:\ecom-nocfinity\backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>